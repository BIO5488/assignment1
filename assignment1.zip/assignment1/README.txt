Please provide the exact command line arguments you used to generate your results.
{How to run nuc_count.py}
{How to run make_seq.py for length 1,000,000 with frequencies used}
-
Question 1:
{nuc_count.py nucleotide counts of human chr22 output}
-
Question 2:
{modified nuc_count.py nucleotide frequencies of human chr22 output}
-
Question 3:
{modified nuc_count.py dinucleotide frequencies of human chr22 output}
-
{modified nuc_count.py dinucleotide frequencies of random_seq_1M.txt output}
-
Compare the two lists of frequencies. What are the differences? Can you provide a biological explanation for these differences?:
{Explanation}
-
Comments:
{Things that went wrong or you cannot figure out}
-
Suggestions:
{What programming and/or genomics topics should the TAs cover in the next class that would have made this assignment go smoother?}
-

